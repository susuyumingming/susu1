#ifndef __SERIAL_H
#define __SERIAL_H

#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Key.h"
#include "sys.h"
#include "Steering_engine.h"
#include "PWM.h"
#include "Servo.h"



#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

extern char Serial_RxPacket[40];
extern int16_t coordinate[8]={0,0,0,0,0,0,0,0};
extern uint8_t Serial_RxFlag;



#endif
