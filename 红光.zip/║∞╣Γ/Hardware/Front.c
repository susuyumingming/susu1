#include "stm32f10x.h"                  // Device header
#include "Key.h"
#include "Servo.h"
#include "OLED.H"
#include "Delay.h"
#include "Steering_engine.h"
#include "Serial.h"

void Write_Dead_Mode(void)
{	
	static float Angle_x=900,Angle_y=900;
	static uint16_t a=0,c=1,d=0;
	static float PWM[10];
	static uint16_t Key=0;
	static int num=0;
	static int8_t x_or_y=0;
	static int8_t mode=0;
	static uint8_t Visual_mode=0;
	a=Key_GetNum();
	OLED_ShowNum(1,1,Key,2);
//	OLED_ShowNum(1,6,x,2);
	
	if(x_or_y==0)				//����x�ļӼ�
	{
		if(a==1)//b12			//����x�ļ�
		{
			Key++;
			Angle_x = Angle_x+c ;
			Servo_SetAngle_x(Angle_x);
			Delay_ms(10);
		}
		if(a==2)//b13			//����x�ļ�
		{
			Key++;
			Angle_x = Angle_x-c ;
			Servo_SetAngle_x(Angle_x);
			Delay_ms(10);
		}
	}
	else if(x_or_y==1)		//����y�ļӼ�
	{
		if(a==1)//b14			//����y�ļ�
		{
			Key++;
			Angle_y = Angle_y+c ;
			Servo_SetAngle_y(Angle_y);
			Delay_ms(10);
		}
		if(a==2)//b15			//����y�ļ�
		{
			Key++;
			Angle_y = Angle_y - c ;
			Servo_SetAngle_y(Angle_y);
		}
	}
	
	if(a==3)						//ģʽѡ�񣬿���x��y�ļӼ�
	{
		Key++;
		x_or_y = x_or_y +1;
		if(x_or_y>=2)
		{
			x_or_y=0;
		}
	}
	if(a==4)//a9				//�Ӽ����ȵ���
	{
		Key++;
		d++;
		if(d==1)
		{
			c = 1;
		}
		if(d==2)
		{
			c = 10;
		}
		if(d==3)
		{
			c = 100;
		}
		if(d>=4)
		{
			d=0;
		}
	}	
	if(a==5)//a8				//��������
	{
		Key++;
		PWM[num]=Angle_x;
		PWM[num+1]=Angle_y;
		num =num+2;
	}
	if(a==6)						//�ƶ�ģʽѡ��
	{
		Key++;
		mode++;
		if(mode==1)				//�߿�ģʽ
		{
			Servo_SetAngle_x(PWM[2]);
			Servo_SetAngle_y(PWM[3]);
			Delay_ms(1000);
			Servo_SetAngle_x(PWM[4]);
			Servo_SetAngle_y(PWM[5]);
			Delay_ms(1000);
			Servo_SetAngle_x(PWM[6]);
			Servo_SetAngle_y(PWM[7]);
			Delay_ms(1000);
			Servo_SetAngle_x(PWM[8]);
			Servo_SetAngle_y(PWM[9]);
			Delay_ms(1000);
			mode ++;
		}
		else if(mode==3)		//����ģʽ
		{
			Servo_SetAngle_x(PWM[0]);
			Servo_SetAngle_y(PWM[1]);
			Delay_ms(1000);	
			mode ++;			
		}
		else if(mode >=4)
		{
			mode =0;
		}
	}
//	if(a==7)//a10
//	{
//		Key++;

//	}
//	if(a==8)//a11
//	{
//		Key++;

//	}
//	if(a==1)
//	{
//		Key++;
//		Mode = 1;
//	}
//	if(a==2)
//	{
//		Key++;
//		Serial_SendByte(0xfc);
//	}
//	if(a==3)
//	{
//		Key++;
//		Serial_SendByte(0xfa);
//	}
//	if(a==4)
//	{
//		Key++;
//		Serial_SendByte(0xfe);
//	}
	OLED_ShowNum(2,1,Angle_x,3);
	OLED_ShowNum(2,5,Angle_y,3);
	OLED_ShowNum(2,9,PWM[0],3);
	OLED_ShowNum(2,13,PWM[1],3);
	OLED_ShowNum(3,1,PWM[2],3);
	OLED_ShowNum(3,5,PWM[3],3);
	OLED_ShowNum(3,9,PWM[4],3);
	OLED_ShowNum(3,13,PWM[5],3);
	OLED_ShowNum(4,1,PWM[6],3);
	OLED_ShowNum(4,5,PWM[7],3);
	OLED_ShowNum(4,9,PWM[8],3);
	OLED_ShowNum(4,13,PWM[9],3);


}



//void Visual_mode(void)
//{

//	Visual_mode=Key_GetNum();
//	OLED_ShowNum(1,1,Key,2);
//	if(Visual_mode==1)
//	{
//		Key++;
//		Mode = 1;
//	}
//	if(Visual_mode==2)
//	{
//		Key++;
//		Serial_SendByte(0xfc);
//	}
//	if(Visual_mode==3)
//	{
//		Key++;
//		Serial_SendByte(0xfa);
//	}
//	if(Visual_mode==4)
//	{
//		Key++;
//		Serial_SendByte(0xfe);
//	}
//	
//	
//	
//}

