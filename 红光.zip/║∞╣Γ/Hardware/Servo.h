#ifndef __SERVO_H
#define __SERVO_H


void Servo1_Init(void);
void Servo_SetAngle_x(float Angle);
void Servo_SetAngle_y(float Angle);
void Servo_SetAngle_x_l(float Angle);
void Servo_SetAngle_y_l(float Angle);


#endif


