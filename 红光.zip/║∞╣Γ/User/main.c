/*
									_oo0oo_
								  o8888888o
                          88" . "88
								  (| -_- |)
								  0\  =  /0
							  ____/`---'\____	  
						  . '  \\|     |//  `.
						 /	  \\|||  :  |||//  \
						/   _||||| -:- |||||-  \
					   |    | \\\  -  /// |   |
						|  \_|  ''\---/''  |   |
						\   .-\__  `-`  ___/-. /
					 ___`. .'   /--.--\  '. . __
				."" '<   `.____\_<|>_/___.'  >'""
				| |:  `- \ `. ;`\ _ /`;.`/ - ` : | |
				\ \ `-.   \_ ___ \ /__ _/    .-`/  /
		 ======`-.___`-.___\________/___.-`___.-'======
		                   `=------='
		 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				    佛主保佑            永无BUG
*/

/*
	版本1.0
	1、添加了位置式和增量式pid
	2、舵机初始化参数使用全局变量和 define 宏定义，更改Initialize_x，Initialize_y，即可改变初始化角度
	3、优化逻辑
	4、边框数据包头为“#”，包尾为“b”，包尾前需加上“，”，及数据包最后两位为“，b”
	5、激光数据包头为“@”，包尾为“j”，包尾前需加上“，”，及数据包最后两位为“，j”
	6、位置式和增量式pid变量要求有所不同，需要解锁一下变量
*/



#include "stm32f10x.h"                  // Device header
#include "Serial.h"
#include "OLED.H"
#include "Key.h"
#include "Delay.h"
#include "Steering_engine.h"
#include <string.h>
#include <stdlib.h>
#include "Servo.h"
#include "Front.h"

int8_t abcd=0,xtz=0;

float PWM_pencil_x[100]={0};
float PWM_pencil_y[100]={0};

//红，Y轴连A7,X轴连A6
//绿，Y轴连B1,X轴连B0

int main(void)
{
	/*模块初始化*/
	OLED_Init();		//OLED初始化
	Key_Init();	
	Servo1_Init();
	Serial_Init();		//串口初始化	
	Timer_Init();	   //定时中断
//	Timer4_Init();
	while (1)
	{
		USARTData_processing();								//串口接收数据处理函数
//		Write_Dead_Mode();											//一二题，写死的按键控制
//		Visual_mode();
		abcd= Key_GetNum();
		OLED_ShowNum(1,1,xtz,2);
		OLED_ShowNum(2, 1, coordinate_laser[0],3);			//OLED清除指定位置，并显示接收到的数据包
		OLED_ShowNum(2, 5, coordinate_laser[1],3);			//OLED清除指定位置，并显示接收到的数据包
//		OLED_ShowNum(4, 9, coordinate_frame_subdivide_x[0],3);			//OLED清除指定位置，并显示接收到的数据包
//		OLED_ShowNum(4, 13, coordinate_frame_subdivide_y[0],3);			//OLED清除指定位置，并显示接收到的数据包
		OLED_ShowNum(4, 1, coordinate_frame[0],3);			//OLED清除指定位置，并显示接收到的数据包
		OLED_ShowNum(4, 5, coordinate_frame[1],3);			//OLED清除指定位置，并显示接收到的数据包

		if(abcd==1)//启动，暂停
		{
			xtz++;
			Mode_Tim += 1;
			if(Mode_Tim>=3)
			{
				Mode_Tim=1;
			}
		}
		if(abcd==2)//识别边框
		{			
			xtz++;
			Serial_SendByte(0xFC);
		}
		if(abcd==3)//识别激光
		{
			xtz++;
			Serial_SendByte(0xFA);
		}
		if(abcd==4)//视觉关闭
		{
			xtz++;
			Serial_SendByte(0xFE);
		}	
		if(abcd==5)//舵机初始化
		{
			xtz++;
			Servo_SetAngle_x(Initialize_x);
			Servo_SetAngle_y(Initialize_y);
		}
		if(abcd==6) //铅笔
		{
//			Slope_pencl=0;
//			Mode=2;
			
//			int16_t n = 3;					//取中心次数
//			int16_t num = 0;							//两角之间的点
//			
//			num = lifan(n);
//			
//			PWM_pencil_x[0 * num] = 1104;
//			PWM_pencil_y[0 * num] = 960;
//			
//			PWM_pencil_x[1 * num] = 830;
//			PWM_pencil_y[1 * num] = 960;
//			
//			PWM_pencil_x[2 * num] = 802;
//			PWM_pencil_y[2 * num] = 1245;
//			
//			PWM_pencil_x[3 * num] = 1100;
//			PWM_pencil_y[3 * num] = 1245;
//			
//			PWM_pencil_x[4 * num] = 1104;
//			PWM_pencil_y[4 * num] = 960;
//			
//			int b = 0;
//			
//			for (; n > 0; n--) 
//			{
//				for (int a = 0; a < (5 * lifan(b)); a++) 
//				{
//					coordinate_frame_pencil_subdivide_x[((a * lifan(n)+(a+1)*lifan(n))/2)] = ((coordinate_frame_pencil_subdivide_x[a * lifan(n)] + coordinate_frame_pencil_subdivide_x[a * lifan(n) + lifan(n)])/2);
//					coordinate_frame_pencil_subdivide_y[((a * lifan(n)+(a+1)*lifan(n))/2)] = ((coordinate_frame_pencil_subdivide_y[a * lifan(n)] + coordinate_frame_pencil_subdivide_y[a * lifan(n) + lifan(n)])/2);
//				}
//				b++;
//			}
//			
//			for(int i=0;i<32;i++)
//			{
//				Servo_SetAngle_x(PWM_pencil_x[i]);
//				Servo_SetAngle_y(PWM_pencil_y[i]);
//				Delay_ms(500);
//			}
			
			
			Servo_SetAngle_x(1104);//
			Servo_SetAngle_y(965);
			Delay_ms(1000);
			
			Servo_SetAngle_x(1035.5);
			Servo_SetAngle_y(965);
			Delay_ms(1000);			
			
			Servo_SetAngle_x(967);
			Servo_SetAngle_y(965);
			Delay_ms(1000);
			
			Servo_SetAngle_x(898.5);
			Servo_SetAngle_y(965);
			Delay_ms(1000);			
	
			Servo_SetAngle_x(830);//
			Servo_SetAngle_y(965);
			Delay_ms(1000);
			
			Servo_SetAngle_x(823);
			Servo_SetAngle_y(1033.75);
			Delay_ms(1000);			
			
			Servo_SetAngle_x(816);
			Servo_SetAngle_y(1102.5);
			Delay_ms(1000);
			
			Servo_SetAngle_x(809);
			Servo_SetAngle_y(1173.75);
			Delay_ms(1000);
			
			Servo_SetAngle_x(802);//
			Servo_SetAngle_y(1245);
			Delay_ms(1000);
	
			Servo_SetAngle_x(876.5);
			Servo_SetAngle_y(1245);
			Delay_ms(1000);

			Servo_SetAngle_x(951);
			Servo_SetAngle_y(1245);
			Delay_ms(1000);
	
			Servo_SetAngle_x(1025.5);
			Servo_SetAngle_y(1245);
			Delay_ms(1000);

			Servo_SetAngle_x(1100);//
			Servo_SetAngle_y(1245);
			Delay_ms(1000);

			Servo_SetAngle_x(1101);
			Servo_SetAngle_y(1173.75);
			Delay_ms(1000);

			Servo_SetAngle_x(1102);
			Servo_SetAngle_y(1102.5);
			Delay_ms(1000);
	
			Servo_SetAngle_x(1103);
			Servo_SetAngle_y(1031.25);
			Delay_ms(1000);

			Servo_SetAngle_x(1104);//
			Servo_SetAngle_y(965);
			Delay_ms(1000);
			
			
			
		}
		if(abcd==7) //胶布
		{			
			Slope_frame=0;
			Mode=1;

		}
		if(abcd==8) //中心
		{
			Mode=3;
		}
		if(abcd==9)
		{
			
		}	
		
	}	
	
}


