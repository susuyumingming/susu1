#ifndef __USART3_H
#define __USART3_H

#include "sys.h" 
#include <stdio.h>
#include <stdarg.h>


//void USART3_Send_String(char *String);
//void uart3_init(u32 bound);					//����1��ʼ������
//void USART3_IRQHandler(void);     	//����1�жϷ������

void uart3_init(u32 bound);
void Serial_SendByte(uint16_t Byte);
void Serial_SendArray(uint16_t *Array, uint16_t Length);
void Serial_SendString(char *String);
uint32_t Serial_Pow(uint32_t X, uint32_t Y);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf(char *format, ...);
void Serial_SendPacket(void);
void USART3_IRQHandler(void);





#endif
