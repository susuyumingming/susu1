#ifndef  _EXTI_H
#define  _EXTI_H

void MPU6050_EXTI_Init(void);

#endif


