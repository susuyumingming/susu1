#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "Key.h"
#include "sys.h" 
#include "Timer.h"
#include "usart.h"
#include "usart2.h"

int menu1_flag_1=1;         //�׽���ѡ��
int menu1_flag_2=1;         //ƽ�⳵���н���ѡ��
int menu1_flag_3=1;         //������ѡ��
int menu1_flag_mode=0;         //ѡ��
int16_t menul_Y=0;							//����
int16_t menul_X=0;							//����
int mode=0;

void UI(void)
{
	uint8_t key;
	
	key = Key_GetNum();
	
	if(menu1_flag_mode==0)	//�׽���
	{
		if(key==2)			//�¼�
		{
			menu1_flag_1++;
			if(menu1_flag_1==5)
			{
				menu1_flag_1=1;
			}
//			OLED_Clear();		
		}
		else if(key==4)	//�ϼ�
		{
			menu1_flag_1--;
			if(menu1_flag_1==0)
			{
				menu1_flag_1=4;
			}
//			OLED_Clear();		
		}
		else if(key==1)	//ȷ����
		{
			if(menu1_flag_1==1)				//����ƽ�⳵
			{
				menu1_flag_1=1;
				mode=1;
				menu1_flag_mode=1;
			}
			else if(menu1_flag_1==3)	//����:JY_61
			{
				menu1_flag_1=1;
				menu1_flag_mode=2;
			}
			else if(menu1_flag_1==4)	//����MPU_6050
			{
				menu1_flag_1=1;
				menu1_flag_mode=2;
			}
//			OLED_Clear();
		}
		switch(menu1_flag_1)
		{
			case 1:
			{	
				OLED_Clear();		
				OLED_ShowChinese(0, 0, "����ƽ�⳵");OLED_ShowString(80,0,":JY_61",OLED_8X16);
				OLED_ShowChinese(0, 16, "����ƽ�⳵");OLED_ShowString(80,16,":MPU6050",OLED_8X16);
				OLED_ShowChinese(0, 32, "����");OLED_ShowString(32,32,":JY_61",OLED_8X16);
				OLED_ShowChinese(0, 48, "����");OLED_ShowString(32,48,":MPU6050",OLED_8X16);
				OLED_ShowFloatNum(88,32,JY_61.Pitch,2,1,OLED_8X16);
				OLED_ReverseArea(0,0,80,16);
			}
				break;
			case 2:
			{
				OLED_Clear();		
				OLED_ShowChinese(0, 0, "����ƽ�⳵");OLED_ShowString(80,0,":JY_61",OLED_8X16);
				OLED_ShowChinese(0, 16, "����ƽ�⳵");OLED_ShowString(80,16,":MPU6050",OLED_8X16);
				OLED_ShowChinese(0, 32, "����");OLED_ShowString(32,32,":JY_61",OLED_8X16);
				OLED_ShowChinese(0, 48, "����");OLED_ShowString(32,48,":MPU6050",OLED_8X16);
				OLED_ShowFloatNum(88,32,JY_61.Pitch,2,1,OLED_8X16);
				OLED_ReverseArea(0,16,80,16);
			}
				break;
			case 3:
			{
				OLED_Clear();		
				OLED_ShowChinese(0, 0, "����ƽ�⳵");OLED_ShowString(80,0,":JY_61",OLED_8X16);
				OLED_ShowChinese(0, 16, "����ƽ�⳵");OLED_ShowString(80,16,":MPU6050",OLED_8X16);
				OLED_ShowChinese(0, 32, "����");OLED_ShowString(32,32,":JY_61",OLED_8X16);
				OLED_ShowChinese(0, 48, "����");OLED_ShowString(32,48,":MPU6050",OLED_8X16);
				OLED_ShowFloatNum(88,32,JY_61.Pitch,2,1,OLED_8X16);
				OLED_ReverseArea(0,32,32,16);
			}
				break;
			case 4:
			{
				OLED_Clear();		
				OLED_ShowChinese(0, 0, "����ƽ�⳵");OLED_ShowString(80,0,":JY_61",OLED_8X16);
				OLED_ShowChinese(0, 16, "����ƽ�⳵");OLED_ShowString(80,16,":MPU6050",OLED_8X16);
				OLED_ShowChinese(0, 32, "����");OLED_ShowString(32,32,":JY_61",OLED_8X16);
				OLED_ShowChinese(0, 48, "����");OLED_ShowString(32,48,":MPU6050",OLED_8X16);
				OLED_ShowFloatNum(88,32,JY_61.Pitch,2,1,OLED_8X16);
				OLED_ReverseArea(0,48,32,16);
			}
				break;
			default:
				break;
		}
	}
	else if(menu1_flag_mode==1)	//ƽ�⳵���н���
	{
		if(key==1)	//ȷ����	//ֹͣƽ�⳵
		{
			menu1_flag_2=1;			
			mode=0;
			menu1_flag_mode=0;
//			OLED_Clear();
		}
		switch(menu1_flag_2)
		{
			case 1:
			{
				OLED_Clear();		
				OLED_ShowChinese(0, 0, "ֹͣƽ�⳵");OLED_ShowNum(90,0,Fore,2,OLED_8X16);
				OLED_ShowSignedNum(0,16,Encoder_Left,6,OLED_6X8);
				OLED_ShowSignedNum(0,24,Encoder_Right,6,OLED_6X8);
				OLED_ShowFloatNum(0,32,JY_61.Pitch,3,4,OLED_6X8);
//				OLED_ShowFloatNum(0,40,Yaw,3,4,OLED_6X8);
				OLED_ShowFloatNum(0,48,JY_61.gyroy,3,4,OLED_6X8);
				OLED_ShowFloatNum(0,56,Vertical_out,4,4,OLED_6X8);
				
				
				OLED_ReverseArea(0,0,80,16);
				
			}
				break;
			default:
				break;
		}
	}
	else if(menu1_flag_mode==2)	//���ν���
	{
		if(key==2)			//�¼�
		{
			if(menul_X<12&&menul_X>=0)
			{
				menul_Y++;
				if(menul_Y==8)
				{
					menul_Y=0;
				}			
			}
			else if(menul_X>12&&menul_X<21)
			{
				switch(menul_Y)
				{
					case 0:
						switch(menul_X)
						{
							case 13:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp-1000;
								break;
							case 14:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp-100;
								break;
							case 15:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp-10;
								break;
							case 16:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp-1;
								break;
							case 18:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp-0.1;
								break;
							case 19:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp-0.01;
								break;
							case 20:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp-0.001;
								break;
							default:
								break;
						}
						break;
					case 1:
						switch(menul_X)
						{
							case 13:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd-1000;
								break;
							case 14:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd-100;
								break;
							case 15:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd-10;
								break;
							case 16:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd-1;
								break;
							case 18:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd-0.1;
								break;
							case 19:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd-0.01;
								break;
							case 20:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd-0.001;
								break;
							default:
								break;
						}
						break;
					case 2:
						switch(menul_X)
						{
							case 13:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp-1000;
								break;
							case 14:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp-100;
								break;
							case 15:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp-10;
								break;
							case 16:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp-1;
								break;
							case 18:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp-0.1;
								break;
							case 19:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp-0.01;
								break;
							case 20:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp-0.001;
								break;
							default:
								break;
						}
						break;
					case 3:
						switch(menul_X)
						{
							case 13:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki-1000;
								break;
							case 14:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki-100;
								break;
							case 15:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki-10;
								break;
							case 16:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki-1;
								break;
							case 18:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki-0.1;
								break;
							case 19:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki-0.01;
								break;
							case 20:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki-0.001;
								break;
							default:
								break;
						}
						break;
					case 4:
						switch(menul_X)
						{
							case 13:
								JY_61.Turn_Kd=JY_61.Turn_Kd-1000;
								break;
							case 14:
								JY_61.Turn_Kd=JY_61.Turn_Kd-100;
								break;
							case 15:
								JY_61.Turn_Kd=JY_61.Turn_Kd-10;
								break;
							case 16:
								JY_61.Turn_Kd=JY_61.Turn_Kd-1;
								break;
							case 18:
								JY_61.Turn_Kd=JY_61.Turn_Kd-0.1;
								break;
							case 19:
								JY_61.Turn_Kd=JY_61.Turn_Kd-0.01;
								break;
							case 20:
								JY_61.Turn_Kd=JY_61.Turn_Kd-0.001;
								break;
							default:
								break;
						}
						break;
					case 5:
						switch(menul_X)
						{
							case 13:
								JY_61.Turn_Kp=JY_61.Turn_Kp-1000;
								break;
							case 14:
								JY_61.Turn_Kp=JY_61.Turn_Kp-100;
								break;
							case 15:
								JY_61.Turn_Kp=JY_61.Turn_Kp-10;
								break;
							case 16:
								JY_61.Turn_Kp=JY_61.Turn_Kp-1;
								break;
							case 18:
								JY_61.Turn_Kp=JY_61.Turn_Kp-0.1;
								break;
							case 19:
								JY_61.Turn_Kp=JY_61.Turn_Kp-0.01;
								break;
							case 20:
								JY_61.Turn_Kp=JY_61.Turn_Kp-0.001;
								break;
							default:
								break;
						}
						break;
					case 6:
						switch(menul_X)
						{
							case 13:
								JY_61.Med_Angle=JY_61.Med_Angle-1000;
								break;
							case 14:
								JY_61.Med_Angle=JY_61.Med_Angle-100;
								break;
							case 15:
								JY_61.Med_Angle=JY_61.Med_Angle-10;
								break;
							case 16:
								JY_61.Med_Angle=JY_61.Med_Angle-1;
								break;
							case 18:
								JY_61.Med_Angle=JY_61.Med_Angle-0.1;
								break;
							case 19:
								JY_61.Med_Angle=JY_61.Med_Angle-0.01;
								break;
							case 20:
								JY_61.Med_Angle=JY_61.Med_Angle-0.001;
								break;
							default:
								break;
						}
						break;
					default:
						break;
				}
			}
//			OLED_Clear();		
		}
		else if(key==4)	//�ϼ�
		{
			if(menul_X<12&&menul_X>=0)
			{
				menul_Y--;
				if(menul_Y==-1)
				{
					menul_Y=7;
				}		
			}
			else if(menul_X>12&&menul_X<21)
			{
				switch(menul_Y)
				{
					case 0:
						switch(menul_X)
						{
							case 13:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp+1000;
								break;
							case 14:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp+100;
								break;
							case 15:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp+10;
								break;
							case 16:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp+1;
								break;
							case 18:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp+0.1;
								break;
							case 19:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp+0.01;
								break;
							case 20:
								JY_61.Vertical_Kp=JY_61.Vertical_Kp+0.001;
								break;
							default:
								break;
						}
						break;
					case 1:
						switch(menul_X)
						{
							case 13:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd+1000;
								break;
							case 14:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd+100;
								break;
							case 15:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd+10;
								break;
							case 16:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd+1;
								break;
							case 18:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd+0.1;
								break;
							case 19:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd+0.01;
								break;
							case 20:
								JY_61.Vertical_Kd=JY_61.Vertical_Kd+0.001;
								break;
							default:
								break;
						}
						break;
					case 2:
						switch(menul_X)
						{
							case 13:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp+1000;
								break;
							case 14:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp+100;
								break;
							case 15:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp+10;
								break;
							case 16:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp+1;
								break;
							case 18:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp+0.1;
								break;
							case 19:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp+0.01;
								break;
							case 20:
								JY_61.Velocity_Kp=JY_61.Velocity_Kp+0.001;
								break;
							default:
								break;
						}
						break;
					case 3:
						switch(menul_X)
						{
							case 13:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki+1000;
								break;
							case 14:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki+100;
								break;
							case 15:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki+10;
								break;
							case 16:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki+1;
								break;
							case 18:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki+0.1;
								break;
							case 19:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki+0.01;
								break;
							case 20:
								JY_61.Velocity_Ki=JY_61.Velocity_Ki+0.001;
								break;
							default:
								break;
						}
						break;
					case 4:
						switch(menul_X)
						{
							case 13:
								JY_61.Turn_Kd=JY_61.Turn_Kd+1000;
								break;
							case 14:
								JY_61.Turn_Kd=JY_61.Turn_Kd+100;
								break;
							case 15:
								JY_61.Turn_Kd=JY_61.Turn_Kd+10;
								break;
							case 16:
								JY_61.Turn_Kd=JY_61.Turn_Kd+1;
								break;
							case 18:
								JY_61.Turn_Kd=JY_61.Turn_Kd+0.1;
								break;
							case 19:
								JY_61.Turn_Kd=JY_61.Turn_Kd+0.01;
								break;
							case 20:
								JY_61.Turn_Kd=JY_61.Turn_Kd+0.001;
								break;
							default:
								break;
						}
						break;
					case 5:
						switch(menul_X)
						{
							case 13:
								JY_61.Turn_Kp=JY_61.Turn_Kp+1000;
								break;
							case 14:
								JY_61.Turn_Kp=JY_61.Turn_Kp+100;
								break;
							case 15:
								JY_61.Turn_Kp=JY_61.Turn_Kp+10;
								break;
							case 16:
								JY_61.Turn_Kp=JY_61.Turn_Kp+1;
								break;
							case 18:
								JY_61.Turn_Kp=JY_61.Turn_Kp+0.1;
								break;
							case 19:
								JY_61.Turn_Kp=JY_61.Turn_Kp+0.01;
								break;
							case 20:
								JY_61.Turn_Kp=JY_61.Turn_Kp+0.001;
								break;
						}
						break;
					case 6:
						switch(menul_X)
						{
							case 13:
								JY_61.Med_Angle=JY_61.Med_Angle+1000;
								break;
							case 14:
								JY_61.Med_Angle=JY_61.Med_Angle+100;
								break;
							case 15:
								JY_61.Med_Angle=JY_61.Med_Angle+10;
								break;
							case 16:
								JY_61.Med_Angle=JY_61.Med_Angle+1;
								break;
							case 18:
								JY_61.Med_Angle=JY_61.Med_Angle+0.1;
								break;
							case 19:
								JY_61.Med_Angle=JY_61.Med_Angle+0.01;
								break;
							case 20:
								JY_61.Med_Angle=JY_61.Med_Angle+0.001;
								break;
							default:
								break;
						}
						break;
					default:
						break;
				}
			}
//			OLED_Clear();		
		}
		else if(key==1)	//ȷ����
		{
			if(menul_X==12)
			{
				switch(menul_Y)
				{
					case 0:
						JY_61.Vertical_Kp=-JY_61.Vertical_Kp;
						break;
					case 1:
						JY_61.Vertical_Kd=-JY_61.Vertical_Kd;
						break;
					case 2:
						JY_61.Velocity_Kp=-JY_61.Velocity_Kp;
						break;
					case 3:
						JY_61.Velocity_Ki=-JY_61.Velocity_Ki;
						break;
					case 4:
						JY_61.Turn_Kd=-JY_61.Turn_Kd;
						break;
					case 5:
						JY_61.Turn_Kp=-JY_61.Turn_Kp;
						break;

					default:
						break;
				}
			}else 
			{
				menu1_flag_mode=0;				
			}
//			OLED_Clear();
		}
		else if(key==5)	//���
		{
			menul_X--;
			if(menul_X==-1)
			{
				menul_X=20;
			}
//			OLED_Clear();
		}
		else if(key==3)	//�Ҽ�
		{
			menul_X++;
			if(menul_X==21)
			{
				menul_X=0;
			}
//			OLED_Clear();
		}
		OLED_Clear();		
		OLED_ShowString(0,0,"Vertical_Kp:",OLED_6X8);OLED_ShowFloatNum(72,0,JY_61.Vertical_Kp,4,3,OLED_6X8);
		OLED_ShowString(0,8,"Vertical_Kd:",OLED_6X8);OLED_ShowFloatNum(72,8,JY_61.Vertical_Kd,4,3,OLED_6X8);
		OLED_ShowString(0,16,"Velocity_Kp:",OLED_6X8);OLED_ShowFloatNum(72,16,JY_61.Velocity_Kp,4,3,OLED_6X8);
		OLED_ShowString(0,24,"Velocity_Ki:",OLED_6X8);OLED_ShowFloatNum(72,24,(JY_61.Velocity_Kp/200),2,5,OLED_6X8);
		OLED_ShowString(0,32,"Turn_Kd:",OLED_6X8);OLED_ShowFloatNum(72,32,JY_61.Turn_Kd,4,3,OLED_6X8);
		OLED_ShowString(0,40,"Turn_Kp:",OLED_6X8);OLED_ShowFloatNum(72,40,JY_61.Turn_Kp,4,3,OLED_6X8);
		OLED_ShowString(0,48,"Med_Angle:",OLED_6X8);OLED_ShowFloatNum(72,48,JY_61.Med_Angle,4,3,OLED_6X8);
		OLED_ReverseArea(menul_X*6,menul_Y*8,6,8);
	}
	OLED_Update();
}






