#ifndef __MY_UI_H
#define __MY_UI_H

extern int mode;

void UI(void);

#endif


