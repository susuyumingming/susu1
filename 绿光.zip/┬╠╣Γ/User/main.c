/*
									_oo0oo_
								  o8888888o
                          88" . "88
								  (| -_- |)
								  0\  =  /0
							  ____/`---'\____	  
						  . '  \\|     |//  `.
						 /	  \\|||  :  |||//  \
						/   _||||| -:- |||||-  \
					   |    | \\\  -  /// |   |
						|  \_|  ''\---/''  |   |
						\   .-\__  `-`  ___/-. /
					 ___`. .'   /--.--\  '. . __
				."" '<   `.____\_<|>_/___.'  >'""
				| |:  `- \ `. ;`\ _ /`;.`/ - ` : | |
				\ \ `-.   \_ ___ \ /__ _/    .-`/  /
		 ======`-.___`-.___\________/___.-`___.-'======
		                   `=------='
		 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				    佛主保佑            永无BUG
*/

/*
	版本1.0
	1、添加了位置式和增量式pid
	2、舵机初始化参数使用全局变量和 define 宏定义，更改Initialize_x，Initialize_y，即可改变初始化角度
	3、优化逻辑
	4、边框数据包头为“#”，包尾为“b”，包尾前需加上“，”，及数据包最后两位为“，b”
	5、激光数据包头为“@”，包尾为“j”，包尾前需加上“，”，及数据包最后两位为“，j”
	6、位置式和增量式pid变量要求有所不同，需要解锁一下变量
*/



#include "stm32f10x.h"                  // Device header
#include "Serial.h"
#include "OLED.H"
#include "Key.h"
#include "Delay.h"
#include "Steering_engine.h"
#include <string.h>
#include <stdlib.h>
#include "Servo.h"
#include "Front.h"
#include "Buzzer.h"

int8_t abcd=0,xtz=0;

float PWM_pencil_x[100]={0};
float PWM_pencil_y[100]={0};

//红，Y轴连A7,X轴连A6
//绿，Y轴连B1,X轴连B0

int main(void)
{
	/*模块初始化*/
	OLED_Init();		//OLED初始化
	Key_Init();	
	buzzer_Init();
	Servo1_Init();
	Serial_Init();		//串口初始化	
	Timer_Init();	   //定时中断
	buzzer_Init();
//	Timer4_Init();
	while (1)
	{
		USARTData_processing();								//串口接收数据处理函数
//		Write_Dead_Mode();											//一二题，写死的按键控制
//		Visual_mode();
		abcd= Key_GetNum();
		OLED_ShowNum(1,1,xtz,2);
		OLED_ShowNum(2, 1, coordinate_laser[0],3);			//OLED清除指定位置，并显示接收到的数据包
		OLED_ShowNum(2, 5, coordinate_laser[1],3);			//OLED清除指定位置，并显示接收到的数据包
//		OLED_ShowNum(4, 9, coordinate_frame_subdivide_x[0],3);			//OLED清除指定位置，并显示接收到的数据包
//		OLED_ShowNum(4, 13, coordinate_frame_subdivide_y[0],3);			//OLED清除指定位置，并显示接收到的数据包
		OLED_ShowNum(4, 1, coordinate_frame[0],3);			//OLED清除指定位置，并显示接收到的数据包
		OLED_ShowNum(4, 5, coordinate_frame[1],3);			//OLED清除指定位置，并显示接收到的数据包
		buzzer_off();
		if(abcd==1)//启动，暂停
		{
			xtz++;
			Mode += 1;
			if(Mode>=3)
			{
				Mode=1;
			}
		}
		if(abcd==2)//识别边框
		{			
			xtz++;
			Serial_SendByte(0xFC);
		}
		if(abcd==3)//识别激光
		{
			xtz++;
			Serial_SendByte(0xFA);
		}
		if(abcd==4)//视觉关闭
		{
			xtz++;
			Serial_SendByte(0xFE);
		}	
		if(abcd==5)//舵机初始化
		{
			xtz++;
			Servo_SetAngle_x(PWM_x);
			Servo_SetAngle_y(PWM_y);
		}
	
		
	}	
	
}


