#ifndef __STEERING_ENGINE_H
#define __STEERING_ENGINE_H

extern int16_t coordinate_frame[40]; 
extern int16_t coordinate_laser[8]; 
extern int16_t coordinate_frame_pencil[40];
extern int16_t coordinate_frame_subdivide_x[1000]; 
extern int16_t coordinate_frame_subdivide_y[1000]; 
extern int16_t coordinate_frame_pencil_subdivide_x[1000]; 	//x��
extern int16_t coordinate_frame_pencil_subdivide_y[1000];		//y�� 

extern int Trace_Flag,Trace_Flag_1;//׷�ٱ�־λ

extern float Error_All_x,Error_All_y;

extern int x;

extern int16_t PWM_x,PWM_y;

extern int8_t Slope_pencl,Slope_frame;

extern char Data_x[10];
extern char Data_y[10];
 
extern char DataBlue_x[10];
extern char DataBlue_y[10];
 
extern int16_t Data_xx;//�߿������
extern int16_t Data_yy;//�߿������
 
extern int16_t DataBlue_xx;//���������
extern int16_t DataBlue_yy;//���������

extern int8_t Mode,Mode_Tim;

void Timer_Init(void);
void Timer4_Init(void);

void Slope(void);
void Slope_pencil(void);

void Limit(int16_t *PWM_x,int16_t *PWM_y);
int16_t Servo_PID_x(int16_t Error);  //�������
int16_t Servo_PID_y(int16_t Error);  //�������

int16_t lifan(int16_t n);

#endif


