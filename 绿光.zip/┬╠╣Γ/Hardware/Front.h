#ifndef __FRONT_H
#define __FRONT_H

extern float Angle_x,Angle_y;		

extern uint16_t a=0,b=0,c=1,d=0;
extern int j=0,k=0;
extern float PWM[10];
extern int num=0;


void Write_Dead_Mode(void);
void Visual_mode(void);

#endif


